#include "flutter_embedder.h"
#include <iostream>
#include <string>
#include <memory>

class FlutterApp {
private:
    FlutterEngine engine;
    FlutterEngineResult result;

public:
    bool Initialize() {
        FlutterRendererConfig config = {};
        config.type = kSoftware;
        
        FlutterProjectArgs args = {};
        args.struct_size = sizeof(FlutterProjectArgs);
        args.assets_path = "flutter_assets";
        args.icu_data_path = "icudtl.dat";
        
        result = FlutterEngineRun(FLUTTER_ENGINE_VERSION, &config, &args, nullptr, &engine);
        
        if (result != kSuccess) {
            std::cerr << "Failed to run Flutter engine: " << result << std::endl;
            return false;
        }
        
        std::cout << "Flutter engine initialized successfully!" << std::endl;
        return true;
    }
    
    void Shutdown() {
        if (result == kSuccess) {
            FlutterEngineShutdown(engine);
            std::cout << "Flutter engine shutdown complete." << std::endl;
        }
    }
    
    void Run() {
        std::cout << "IVI Home Screen is running..." << std::endl;
        std::cout << "Press Enter to exit..." << std::endl;
        std::cin.get();
    }
};

int main() {
    std::cout << "Starting IVI Home Screen Application..." << std::endl;
    
    FlutterApp app;
    
    if (!app.Initialize()) {
        return 1;
    }
    
    app.Run();
    app.Shutdown();
    
    return 0;
}
